<?php if (isset($component)) { $__componentOriginala34538f940487e5564b39117d7934596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala34538f940487e5564b39117d7934596 = $attributes; } ?>
<?php $component = App\View\Components\RecruitconnectLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('recruitconnect-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\RecruitconnectLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        $avatar = $user->avatar_path ? asset('storage/'.$user->avatar_path) : 'https://ui-avatars.com/api/?name='.urlencode($user->name).'&background=137fec&color=ffffff&bold=true';

        $isRecruiter = $user->hasRole('recruiter');

        $headline = $isRecruiter
            ? (optional($user->recruiterProfile)->company_name ?? 'Recruiter')
            : (optional(optional($user->employeeProfile)->speciality)->name ?? optional($user->employeeProfile)->speciality ?? 'Job Seeker');

        $location = $isRecruiter
            ? (optional($user->recruiterProfile)->location ?? null)
            : (optional($user->employeeProfile)->location ?? null);

        $experiences = optional($user->employeeProfile)->experiences ?? collect();
        $educations  = optional($user->employeeProfile)->educations ?? collect();
    ?>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <div class="lg:col-span-4 space-y-6">
            <div class="bg-white rounded-2xl border border-[#e5e7eb] p-6 text-center">
                <div class="w-32 h-32 rounded-full mx-auto bg-cover bg-center ring-4 ring-primary/10" style="background-image:url('<?php echo e($avatar); ?>')"></div>
                <h1 class="mt-4 text-2xl font-black text-[#111418]"><?php echo e($user->name); ?></h1>
                <p class="text-primary font-extrabold mt-1"><?php echo e($headline); ?></p>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($location): ?>
                    <p class="text-[#617589] text-sm mt-2 flex items-center justify-center gap-1">
                        <span class="material-symbols-outlined text-base">location_on</span>
                        <?php echo e($location); ?>

                    </p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <div class="space-y-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($relation === 'self'): ?>
                        <a href="<?php echo e(route('profile.edit')); ?>"
                           class="h-11 w-full rounded-xl bg-primary text-white font-extrabold flex items-center justify-center hover:opacity-95">
                            Modifier mon profil
                        </a>

                    <?php elseif($relation === 'connected'): ?>
                        <button disabled
                                class="h-11 w-full rounded-xl bg-[#f0f2f4] text-[#617589] font-extrabold cursor-not-allowed">
                                Connected
                        </button>

                    <?php elseif($relation === 'pending'): ?>
                        <button disabled
                            class="h-11 w-full rounded-xl bg-[#f0f2f4] text-[#617589] font-extrabold cursor-not-allowed">
                            Pending
                        </button>

                    <?php elseif($relation === 'incoming'): ?>
                        <div class="grid grid-cols-2 gap-2">
                            <form method="POST" action="<?php echo e(route('connections.accept', $incomingRequest)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="h-11 w-full rounded-xl bg-primary text-white font-extrabold    hover:opacity-95">
                                    Accepter
                                </button>
                            </form>

                            <form method="POST" action="<?php echo e(route('connections.decline', $incomingRequest)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="h-11 w-full rounded-xl border border-[#e5e7eb] bg-white
                                    text-[#111418] font-extrabold hover:bg-[#f0f2f4]">
                                    Refuser
                                </button>
                            </form>
                        </div>

                    <?php else: ?>
                        <form method="POST" action="<?php echo e(route('connections.request', $user)); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="h-11 w-full rounded-xl bg-primary text-white font-extrabold
                                hover:opacity-95">
                                Connect
                            </button>
                        </form>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    
                    <a href="<?php echo e(route('search.index', ['q' => $user->name])); ?>"
                       class="h-11 w-full rounded-xl bg-[#f0f2f4] text-[#111418] font-extrabold flex items-center justify-center hover:bg-[#e7eaee]">
                        <span class="material-symbols-outlined mr-2">search</span>
                        Find similar
                    </a>
                </div>
            </div>
            <div class="bg-white rounded-2xl border border-[#e5e7eb] p-6">
                <h3 class="text-xs font-black uppercase tracking-wider text-[#617589] mb-4">Information</h3>

                <div class="space-y-4 text-sm">
                    <div class="flex items-center gap-3">
                        <span class="material-symbols-outlined text-primary">mail</span>
                        <span class="text-[#111418]"><?php echo e($user->email); ?></span>
                    </div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isRecruiter && optional($user->recruiterProfile)->website): ?>
                        <div class="flex items-center gap-3">
                            <span class="material-symbols-outlined text-primary">link</span>
                            <span class="text-[#111418]"><?php echo e($user->recruiterProfile->website); ?></span>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="lg:col-span-8 space-y-6">
            <div class="bg-white rounded-2xl border border-[#e5e7eb] p-6">
                <h2 class="text-xl font-black text-[#111418] flex items-center gap-2 mb-4">
                    <span class="material-symbols-outlined text-primary">person</span>
                    About
                </h2>
                <p class="text-[#111418] leading-relaxed">
                    <?php echo e($user->bio ?: 'No bio yet.'); ?>

                </p>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$isRecruiter): ?>
                <div class="bg-white rounded-2xl border border-[#e5e7eb] p-6">
                    <h2 class="text-xl font-black text-[#111418] flex items-center gap-2 mb-6">
                        <span class="material-symbols-outlined text-primary">work</span>
                        Experiences
                    </h2>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="pb-5 mb-5 border-b border-[#f0f2f4] last:border-0 last:pb-0 last:mb-0">
                            <div class="flex flex-wrap items-start justify-between gap-2">
                                <div>
                                    <p class="font-extrabold text-[#111418]"><?php echo e($exp->title); ?></p>
                                    <p class="text-primary font-bold text-sm"><?php echo e($exp->company); ?></p>
                                </div>
                                <span class="text-xs font-bold bg-[#f0f2f4] px-3 py-1 rounded-full text-[#617589]">
                                    <?php echo e($exp->date_start); ?> → <?php echo e($exp->date_end ?? 'Present'); ?>

                                </span>
                            </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($exp->description): ?>
                                <p class="text-sm text-[#617589] mt-2"><?php echo e($exp->description); ?></p>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-[#617589]">No experiences added.</p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="bg-white rounded-2xl border border-[#e5e7eb] p-6">
                    <h2 class="text-xl font-black text-[#111418] flex items-center gap-2 mb-6">
                        <span class="material-symbols-outlined text-primary">school</span>
                        Education
                    </h2>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="pb-5 mb-5 border-b border-[#f0f2f4] last:border-0 last:pb-0 last:mb-0">
                            <p class="font-extrabold text-[#111418]"><?php echo e($edu->degree); ?></p>
                            <p class="text-sm text-[#617589]"><?php echo e($edu->school); ?></p>
                            <p class="text-xs text-[#617589] mt-1">Year: <?php echo e($edu->year ?? '—'); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-[#617589]">No education added.</p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-2xl border border-[#e5e7eb] p-6">
                    <h2 class="text-xl font-black text-[#111418] flex items-center gap-2 mb-4">
                        <span class="material-symbols-outlined text-primary">business</span>
                        Company
                    </h2>
                    <p class="text-sm text-[#617589]">
                        <?php echo e(optional($user->recruiterProfile)->company_name ?? '—'); ?>

                    </p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala34538f940487e5564b39117d7934596)): ?>
<?php $attributes = $__attributesOriginala34538f940487e5564b39117d7934596; ?>
<?php unset($__attributesOriginala34538f940487e5564b39117d7934596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala34538f940487e5564b39117d7934596)): ?>
<?php $component = $__componentOriginala34538f940487e5564b39117d7934596; ?>
<?php unset($__componentOriginala34538f940487e5564b39117d7934596); ?>
<?php endif; ?>
<?php /**PATH /home/thejackal/Documents/Sprint6/Espace-d-Emploi/resources/views/users/show.blade.php ENDPATH**/ ?>