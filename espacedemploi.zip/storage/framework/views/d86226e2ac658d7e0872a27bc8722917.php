<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Espace d’Emploi')); ?></title>

    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body class="bg-background-light text-ink font-display">
    <?php echo $__env->make('layouts.recruitconnect.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="max-w-[1200px] mx-auto px-4 md:px-10 lg:px-20 py-8">
        <?php
            $status = session('status');
            $map = [
                'offer-created'     => 'Offre créée avec succès.',
                'offer-updated'     => 'Offre mise à jour.',
                'offer-closed'      => 'Offre clôturée.',
                'application-sent'  => 'Candidature envoyée.',
                'profile-updated'   => 'Profil mis à jour.',
                'password-updated'  => 'Mot de passe mis à jour.',
            ];
            $flash = $status ? ($map[$status] ?? $status) : null;
        ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flash): ?>
            <div class="mb-6 rounded-2xl border border-emerald-200 bg-emerald-50 text-emerald-800 px-4 py-3 text-sm font-semibold">
                <?php echo e($flash); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($header)): ?>
            <header class="mb-7">
                <div class="flex items-start justify-between gap-4">
                    <div class="min-w-0">
                        <div class="text-2xl md:text-3xl font-black tracking-tight leading-tight">
                            <?php echo e($header); ?>

                        </div>
                        <p class="text-muted mt-1 text-sm md:text-base">
                            <?php echo e($description ?? ''); ?>

                        </p>
                    </div>
                </div>
            </header>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php echo e($slot); ?>

    </main>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH /home/thejackal/Documents/Sprint6/Espace-d-Emploi/resources/views/layouts/app.blade.php ENDPATH**/ ?>