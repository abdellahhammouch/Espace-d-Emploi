<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Connections <?php $__env->endSlot(); ?>

    <div class="space-y-8">
        
        <div class="flex flex-wrap gap-3">
            <div class="min-w-[140px] rounded-2xl bg-white border border-[#f0f2f4] p-4 shadow-soft">
                <p class="text-xs font-bold text-[#617589]">Pending</p>
                <p class="text-2xl font-black text-[#111418]"><?php echo e($pendingCount); ?></p>
            </div>
            <div class="min-w-[140px] rounded-2xl bg-white border border-[#f0f2f4] p-4 shadow-soft">
                <p class="text-xs font-bold text-[#617589]">Suggestions</p>
                <p class="text-2xl font-black text-[#111418]"><?php echo e($suggestionsCount); ?></p>
            </div>
        </div>

        
        <?php
            $tabClass = fn($t) => $tab === $t
                ? 'border-b-2 border-primary text-primary pb-3 font-extrabold'
                : 'border-b-2 border-transparent text-[#617589] pb-3 font-bold hover:text-[#111418]';
        ?>
        <div class="flex gap-8 border-b border-[#e5e7eb]">
            <a class="<?php echo e($tabClass('friends')); ?>" href="<?php echo e(route('connections.index', ['tab' => 'friends'])); ?>">
                My Friends <span class="ml-2 text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-black"><?php echo e($friendsCount); ?></span>
            </a>

            <a class="<?php echo e($tabClass('pending')); ?>" href="<?php echo e(route('connections.index', ['tab' => 'pending'])); ?>">
                Pending <span class="ml-2 text-[10px] px-2 py-0.5 rounded-full bg-[#f0f2f4] text-[#617589] font-black"><?php echo e($pendingCount); ?></span>
            </a>

            <a class="<?php echo e($tabClass('suggestions')); ?>" href="<?php echo e(route('connections.index', ['tab' => 'suggestions'])); ?>">
                Suggestions
            </a>
        </div>

        
        <form method="GET" action="<?php echo e(route('connections.index')); ?>" class="max-w-md">
            <input type="hidden" name="tab" value="<?php echo e($tab); ?>">
            <div class="relative">
                <span class="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-[#617589]">search</span>
                <input name="q" value="<?php echo e($q); ?>"
                    class="w-full h-12 pl-12 pr-4 rounded-2xl bg-white border border-[#e5e7eb]
                           focus:ring-2 focus:ring-primary/30 focus:border-primary"
                    placeholder="Search by name / speciality / company...">
            </div>
        </form>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tab === 'friends'): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $avatar = $u->avatar_path ? asset('storage/'.$u->avatar_path) : 'https://ui-avatars.com/api/?name='.urlencode($u->name).'&background=137fec&color=ffffff&bold=true';
                        $title = $u->hasRole('recruiter')
                            ? (optional($u->recruiterProfile)->company_name ?? 'Recruiter')
                            : (optional(optional($u->employeeProfile)->speciality)->name ?? optional($u->employeeProfile)->speciality ?? 'Employee');
                    ?>

                    <div class="bg-white border border-[#e5e7eb] rounded-2xl p-5 text-center hover:shadow-soft transition">
                        <div class="w-20 h-20 rounded-full mx-auto bg-cover bg-center ring-4 ring-[#f6f7f8]" style="background-image:url('<?php echo e($avatar); ?>')"></div>
                        <h3 class="mt-4 font-extrabold text-[#111418]"><?php echo e($u->name); ?></h3>
                        <p class="text-xs font-bold text-[#617589] mt-1"><?php echo e($title); ?></p>

                        <a href="<?php echo e(route('users.show', $u)); ?>"
                           class="mt-4 h-10 w-full rounded-xl bg-primary text-white font-extrabold flex items-center justify-center hover:opacity-95">
                            View Profile
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-sm text-[#617589]">No friends yet.</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tab === 'pending'): ?>
            <div class="bg-white border border-[#e5e7eb] rounded-2xl overflow-hidden">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $pendingReceived; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $u = $req->sender;
                        $avatar = $u->avatar_path ? asset('storage/'.$u->avatar_path) : 'https://ui-avatars.com/api/?name='.urlencode($u->name).'&background=137fec&color=ffffff&bold=true';
                        $title = $u->hasRole('recruiter')
                            ? (optional($u->recruiterProfile)->company_name ?? 'Recruiter')
                            : (optional(optional($u->employeeProfile)->speciality)->name ?? optional($u->employeeProfile)->speciality ?? 'Employee');
                    ?>

                    <div class="p-4 flex flex-wrap items-center justify-between gap-4 border-b border-[#e5e7eb] last:border-0 hover:bg-[#f8f9fb] transition">
                        <div class="flex items-center gap-4">
                            <div class="w-12 h-12 rounded-full bg-cover bg-center" style="background-image:url('<?php echo e($avatar); ?>')"></div>
                            <div>
                                <p class="text-sm font-extrabold text-[#111418]"><?php echo e($u->name); ?></p>
                                <p class="text-xs text-[#617589]"><?php echo e($title); ?></p>
                                <p class="text-[10px] text-primary font-bold mt-1">Sent <?php echo e($req->created_at->diffForHumans()); ?></p>
                            </div>
                        </div>

                        <div class="flex gap-2">
                            <form method="POST" action="<?php echo e(route('connections.accept', $req)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="px-4 py-2 bg-primary text-white text-xs font-extrabold rounded-xl">Accept</button>
                            </form>

                            <form method="POST" action="<?php echo e(route('connections.decline', $req)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="px-4 py-2 bg-[#f0f2f4] text-[#111418] text-xs font-extrabold rounded-xl">Decline</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-6 text-sm text-[#617589]">No pending requests.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tab === 'suggestions'): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $suggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $avatar = $u->avatar_path ? asset('storage/'.$u->avatar_path) : 'https://ui-avatars.com/api/?name='.urlencode($u->name).'&background=137fec&color=ffffff&bold=true';
                        $title = $u->hasRole('recruiter')
                            ? (optional($u->recruiterProfile)->company_name ?? 'Recruiter')
                            : (optional(optional($u->employeeProfile)->speciality)->name ?? optional($u->employeeProfile)->speciality ?? 'Employee');
                    ?>

                    <div class="bg-white border border-[#e5e7eb] rounded-2xl p-4 text-center">
                        <div class="w-16 h-16 rounded-full mx-auto bg-cover bg-center" style="background-image:url('<?php echo e($avatar); ?>')"></div>
                        <h4 class="mt-3 text-sm font-extrabold text-[#111418]"><?php echo e($u->name); ?></h4>
                        <p class="text-[11px] text-[#617589] mb-1"><?php echo e($title); ?></p>
                        <a href="<?php echo e(route('users.show', $u)); ?>"
                           class="mb-3 inline-block text-sm font-semibold text-primary hover:underline">
                            Voir profil →
                        </a>
                        <form method="POST" action="<?php echo e(route('connections.request', $u)); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="w-full py-2 border border-primary text-primary text-xs font-extrabold rounded-xl hover:bg-primary/5">
                                Connect
                            </button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-sm text-[#617589]">No suggestions.</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/thejackal/Documents/Sprint6/Espace-d-Emploi/resources/views/connections/index.blade.php ENDPATH**/ ?>