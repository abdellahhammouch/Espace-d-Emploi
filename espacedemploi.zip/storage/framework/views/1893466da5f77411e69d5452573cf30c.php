<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        Bonjour, <?php echo e(auth()->user()->name); ?>

     <?php $__env->endSlot(); ?>

    <?php
        $me = auth()->user();
        $openOffers = \App\Models\JobOffer::where('is_closed', false)->count();
        $myApps = \App\Models\Application::where('employee_id', $me->id)->count();

        $latestOffers = \App\Models\JobOffer::query()
            ->with(['recruiter.recruiterProfile', 'contractType'])
            ->withCount('likes')
            ->withExists([
                'likes as liked_by_me' => fn($q) => $q->where('user_id', $me->id),
                'applications as applied_by_me' => fn($q) => $q->where('employee_id', $me->id),
            ])
            ->where('is_closed', false)
            ->latest()
            ->limit(6)
            ->get();
    ?>

    <div class="space-y-6">
        
        <section class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="bg-white rounded-2xl border border-[#f0f2f4] p-5 shadow-soft">
                <p class="text-xs font-bold text-muted uppercase tracking-wider">Offres ouvertes</p>
                <p class="mt-2 text-3xl font-black"><?php echo e($openOffers); ?></p>
            </div>
            <div class="bg-white rounded-2xl border border-[#f0f2f4] p-5 shadow-soft">
                <p class="text-xs font-bold text-muted uppercase tracking-wider">Mes candidatures</p>
                <p class="mt-2 text-3xl font-black"><?php echo e($myApps); ?></p>
            </div>
            <a href="<?php echo e(route('profile.edit', ['tab' => 'cv'])); ?>"
               class="bg-white rounded-2xl border border-[#f0f2f4] p-5 shadow-soft hover:border-primary/30 transition">
                <p class="text-xs font-bold text-muted uppercase tracking-wider">Améliorer mon CV</p>
                <p class="mt-2 text-sm text-muted">Ajoute tes expériences et formations.</p>
                <p class="mt-3 inline-flex text-primary font-bold text-sm">Aller au CV →</p>
            </a>
        </section>

        
        <section class="bg-transparent">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard-user-search', []);

$key = null;

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-3469160418-0', null);

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </section>

        
        <section class="bg-white rounded-2xl border border-[#f0f2f4] shadow-soft overflow-hidden">
            <div class="p-5 flex items-center justify-between border-b border-[#f0f2f4]">
                <h2 class="font-extrabold text-ink">Offres récentes</h2>
                <a class="text-sm font-bold text-primary hover:underline" href="<?php echo e(route('offers.index')); ?>">Voir tout</a>
            </div>

            <div class="p-5 space-y-5">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $latestOffers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('offers._post', ['offer' => $offer], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-sm text-muted">Aucune offre pour le moment.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/thejackal/Documents/Sprint6/Espace-d-Emploi/resources/views/dashboard/employee.blade.php ENDPATH**/ ?>