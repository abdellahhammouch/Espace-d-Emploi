<?php
    $user = $user ?? auth()->user();
    $tab = request('tab', 'general');

    $initials = collect(preg_split('/\s+/', trim($user?->name ?? 'U')))
        ->filter()
        ->map(fn($p) => mb_strtoupper(mb_substr($p, 0, 1)))
        ->take(2)
        ->join('');

    $avatarUrl = $user && $user->avatar_path
        ? asset('storage/' . $user->avatar_path)
        : null;

    $bannerUrl = $user && isset($user->banner_path) && $user->banner_path
        ? asset('storage/' . $user->banner_path)
        : null;

    $employeeProfile = $user?->employeeProfile;
    $recruiterProfile = $user?->recruiterProfile;
    $initials = collect(preg_split('/\s+/', trim($user?->name ?? 'U')))
        ->filter()
        ->map(fn($p) => mb_strtoupper(mb_substr($p, 0, 1)))
        ->take(2)
        ->join('');

    $isRecruiter = $user?->hasRole('recruiter');

    $roleText = $isRecruiter ? 'Verified Recruiter' : 'Candidate';
?>
<?php if (isset($component)) { $__componentOriginala34538f940487e5564b39117d7934596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala34538f940487e5564b39117d7934596 = $attributes; } ?>
<?php $component = App\View\Components\RecruitconnectLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('recruitconnect-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\RecruitconnectLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col gap-2 mb-8">
        <h1 class="text-3xl font-black leading-tight tracking-[-0.033em]">Account Settings</h1>
        <p class="text-[#617589] text-base font-normal">Manage your profile information and security preferences.</p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">

        
        <aside class="lg:col-span-3">
            <div class="bg-white rounded-xl shadow-sm border border-[#f0f2f4] overflow-hidden">

                
                <div class="h-3 bg-[#137fec]/10"></div>

                <div class="p-4">
                    
                    <div class="flex items-center gap-3">
                        
                        <div class="size-12 rounded-full bg-[#137fec] text-white font-extrabold flex items-center justify-center">
                            <?php echo e($initials); ?>

                        </div>

                        
                        <div class="leading-tight">
                            <div class="text-sm font-bold text-[#111418]">
                                <?php echo e($user->name); ?>

                            </div>

                            <div class="text-xs text-[#617589] flex items-center gap-1 mt-1">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isRecruiter): ?>
                                    <span class="material-symbols-outlined text-[16px] text-[#137fec]">verified</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <span><?php echo e($roleText); ?></span>
                            </div>
                        </div>
                    </div>

                    
                    <nav class="flex flex-col gap-2 mt-4">
                        <a href="<?php echo e(route('profile.edit', ['tab' => 'general'])); ?>"
                           class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors
                           <?php echo e(($tab ?? 'general') === 'general'
                                ? 'bg-[#137fec]/10 text-[#137fec] font-bold'
                                : 'text-[#617589] hover:bg-[#f6f7f8]'); ?>">
                            <span class="material-symbols-outlined">person</span>
                            <span class="text-sm">General Profile</span>
                        </a>
                        <a href="<?php echo e(route('profile.edit', ['tab' => 'cv'])); ?>"
                           class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors
                           <?php echo e(($tab ?? 'general') === 'cv'
                                ? 'bg-[#137fec]/10 text-[#137fec] font-bold'
                                : 'text-[#617589] hover:bg-[#f6f7f8]'); ?>">
                            <span class="material-symbols-outlined">work</span>
                            <span class="text-sm">CV</span>
                        </a>
                        <a href="<?php echo e(route('profile.edit', ['tab' => 'security'])); ?>"
                           class="flex items-center gap-3 px-4 py-3 rounded-lg transition-colors
                           <?php echo e(($tab ?? 'general') === 'security'
                                ? 'bg-[#137fec]/10 text-[#137fec] font-bold'
                                : 'text-[#617589] hover:bg-[#f6f7f8]'); ?>">
                            <span class="material-symbols-outlined">lock</span>
                            <span class="text-sm">Security &amp; Password</span>
                        </a>
                    </nav>
                </div>
            </div>
        </aside>
        
        <div class="lg:col-span-9 space-y-8">

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tab === 'general'): ?>
                <section class="bg-white rounded-xl shadow-sm border border-[#f0f2f4] overflow-hidden">
                    <h2 class="text-xl font-bold p-6 border-b border-[#f0f2f4]">Profile Information</h2>

                    <div class="p-6">
                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status') === 'profile-updated'): ?>
                            <div class="mb-5 rounded-xl border border-green-200 bg-green-50 text-green-700 px-4 py-3 text-sm">
                                Profile saved successfully.
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <form method="POST" action="<?php echo e(route('profile.update')); ?>" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>

                            <div>
                                <label class="block text-sm font-semibold mb-2">Full Name</label>
                                <input name="name" value="<?php echo e(old('name', $user->name)); ?>"
                                       class="w-full bg-[#f6f7f8] border-none rounded-lg px-4 py-3 focus:ring-2 focus:ring-[#137fec]">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-2">Email Address</label>
                                <input name="email" type="email" value="<?php echo e(old('email', $user->email)); ?>"
                                       class="w-full bg-[#f6f7f8] border-none rounded-lg px-4 py-3 focus:ring-2 focus:ring-[#137fec]">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            <div class="md:col-span-2">
                                <label class="block text-sm font-semibold mb-2">Professional Bio</label>
                                <textarea name="bio" rows="4"
                                          class="w-full bg-[#f6f7f8] border-none rounded-lg px-4 py-3 focus:ring-2 focus:ring-[#137fec]"
                                          placeholder="Tell candidates about yourself or your firm..."><?php echo e(old('bio', $user->bio)); ?></textarea>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->hasRole('employee')): ?>
                                <div class="md:col-span-2">
                                    <label class="block text-sm font-semibold mb-2">Speciality</label>
                                    <select name="speciality_id"
                                            class="w-full bg-[#f6f7f8] border-none rounded-lg px-4 py-3 focus:ring-2 focus:ring-[#137fec]">
                                        <option value="">-- Choose a speciality --</option>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($sp->id); ?>"
                                                <?php if(old('speciality_id', $employeeProfile?->speciality_id) == $sp->id): echo 'selected'; endif; ?>>
                                                <?php echo e($sp->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </select>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['speciality_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->hasRole('recruiter')): ?>
                                <div>
                                    <label class="block text-sm font-semibold mb-2">Company Name</label>
                                    <input name="company_name" value="<?php echo e(old('company_name', $recruiterProfile?->company_name)); ?>"
                                           class="w-full bg-[#f6f7f8] border-none rounded-lg px-4 py-3 focus:ring-2 focus:ring-[#137fec]">
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold mb-2">Website</label>
                                    <input name="website" value="<?php echo e(old('website', $recruiterProfile?->website)); ?>"
                                           class="w-full bg-[#f6f7f8] border-none rounded-lg px-4 py-3 focus:ring-2 focus:ring-[#137fec]">
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <div class="md:col-span-2 flex justify-end gap-3 mt-2">
                                <a href="<?php echo e(route('profile.edit', ['tab' => 'general'])); ?>"
                                   class="px-6 py-2 rounded-lg text-sm font-bold border border-[#f0f2f4] hover:bg-[#f6f7f8] transition-colors">
                                    Cancel
                                </a>
                                <button class="px-6 py-2 rounded-lg text-sm font-bold bg-[#137fec] text-white hover:opacity-90 transition-colors" type="submit">
                                    Save Profile
                                </button>
                            </div>
                        </form>
                    </div>
                </section>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(($tab ?? 'general') === 'cv'): ?>
                <?php echo $__env->make('profile.partials.cv', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tab === 'security'): ?>
                <section class="bg-white rounded-xl shadow-sm border border-[#f0f2f4] overflow-hidden">
                    <div class="p-6 border-b border-[#f0f2f4] flex items-center justify-between">
                        <h2 class="text-xl font-bold">Security &amp; Password</h2>
                        <span class="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                            <span class="material-symbols-outlined text-xs">shield</span> Enabled
                        </span>
                    </div>

                    <div class="p-6">
                        <?php if(session('status') === 'password-updated'): ?>
                            <div class="mb-5 rounded-xl border border-green-200 bg-green-50 text-green-700 px-4 py-3 text-sm">
                                Password updated successfully.
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <form method="POST" action="<?php echo e(route('password.update')); ?>" class="max-w-2xl space-y-6">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div>
                                <label class="block text-sm font-semibold mb-2">Current Password</label>
                                <input name="current_password" type="password"
                                       class="w-full bg-[#f6f7f8] border-none rounded-lg px-4 py-3 focus:ring-2 focus:ring-[#137fec]">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->updatePassword?->has('current_password')): ?>
                                    <p class="text-xs text-red-600 mt-2"><?php echo e($errors->updatePassword->first('current_password')); ?></p>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-sm font-semibold mb-2">New Password</label>
                                    <input name="password" type="password"
                                           class="w-full bg-[#f6f7f8] border-none rounded-lg px-4 py-3 focus:ring-2 focus:ring-[#137fec]">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->updatePassword?->has('password')): ?>
                                        <p class="text-xs text-red-600 mt-2"><?php echo e($errors->updatePassword->first('password')); ?></p>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-2">Confirm New Password</label>
                                    <input name="password_confirmation" type="password"
                                           class="w-full bg-[#f6f7f8] border-none rounded-lg px-4 py-3 focus:ring-2 focus:ring-[#137fec]">
                                </div>
                            </div>

                            <div class="flex justify-end pt-2">
                                <button class="px-8 py-3 rounded-lg text-sm font-bold bg-[#137fec] text-white hover:opacity-90 transition-all shadow-md active:scale-[0.98]" type="submit">
                                    Update Password
                                </button>
                            </div>
                        </form>
                    </div>
                </section>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala34538f940487e5564b39117d7934596)): ?>
<?php $attributes = $__attributesOriginala34538f940487e5564b39117d7934596; ?>
<?php unset($__attributesOriginala34538f940487e5564b39117d7934596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala34538f940487e5564b39117d7934596)): ?>
<?php $component = $__componentOriginala34538f940487e5564b39117d7934596; ?>
<?php unset($__componentOriginala34538f940487e5564b39117d7934596); ?>
<?php endif; ?>
<?php /**PATH /home/thejackal/Documents/Sprint6/Espace-d-Emploi/resources/views/profile/edit.blade.php ENDPATH**/ ?>