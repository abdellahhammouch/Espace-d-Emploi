<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        Recruiter Dashboard
     <?php $__env->endSlot(); ?>

    <?php
        $me = auth()->user();

        $open = \App\Models\JobOffer::where('recruiter_id', $me->id)->where('is_closed', false)->count();
        $closed = \App\Models\JobOffer::where('recruiter_id', $me->id)->where('is_closed', true)->count();

        $offerIds = \App\Models\JobOffer::where('recruiter_id', $me->id)->pluck('id');
        $apps = \App\Models\Application::whereIn('job_offer_id', $offerIds)->count();

        $latest = \App\Models\JobOffer::where('recruiter_id', $me->id)
            ->withCount('applications')
            ->latest()
            ->limit(6)
            ->get();
    ?>

    <div class="space-y-6">
        <div class="flex flex-wrap gap-3">
            <a href="<?php echo e(route('recruiter.offers.create')); ?>"
               class="inline-flex items-center justify-center px-5 py-3 rounded-2xl bg-primary text-white font-extrabold shadow-soft hover:opacity-95 transition">
                + Créer une offre
            </a>
            <a href="<?php echo e(route('recruiter.offers.index')); ?>"
               class="inline-flex items-center justify-center px-5 py-3 rounded-2xl bg-white border border-[#f0f2f4] font-extrabold hover:border-primary/30 transition">
                Mes offres
            </a>
        </div>

        
        <section class="bg-transparent">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard-user-search', []);

$key = null;

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-2224983797-0', null);

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </section>

        <section class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="bg-white rounded-2xl border border-[#f0f2f4] p-5 shadow-soft">
                <p class="text-xs font-bold text-muted uppercase tracking-wider">Offres ouvertes</p>
                <p class="mt-2 text-3xl font-black"><?php echo e($open); ?></p>
            </div>
            <div class="bg-white rounded-2xl border border-[#f0f2f4] p-5 shadow-soft">
                <p class="text-xs font-bold text-muted uppercase tracking-wider">Candidatures reçues</p>
                <p class="mt-2 text-3xl font-black"><?php echo e($apps); ?></p>
            </div>
            <div class="bg-white rounded-2xl border border-[#f0f2f4] p-5 shadow-soft">
                <p class="text-xs font-bold text-muted uppercase tracking-wider">Offres clôturées</p>
                <p class="mt-2 text-3xl font-black"><?php echo e($closed); ?></p>
            </div>
        </section>

        <section class="bg-white rounded-2xl border border-[#f0f2f4] shadow-soft overflow-hidden">
            <div class="p-5 flex items-center justify-between border-b border-[#f0f2f4]">
                <h2 class="font-extrabold text-ink">Offres récentes</h2>
                <a class="text-sm font-bold text-primary hover:underline" href="<?php echo e(route('recruiter.offers.index')); ?>">Voir tout</a>
            </div>

            <div class="divide-y divide-[#f0f2f4]">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-5 flex items-center justify-between gap-4">
                        <div class="min-w-0">
                            <p class="font-extrabold text-ink truncate"><?php echo e($offer->title); ?></p>
                            <p class="text-sm text-muted truncate">
                                <?php echo e($offer->place); ?> • <?php echo e($offer->is_closed ? 'Clôturée' : 'Ouverte'); ?> • <?php echo e($offer->applications_count); ?> candidatures
                            </p>
                        </div>

                        <div class="flex gap-2 shrink-0">
                            <a class="px-4 py-2 rounded-xl bg-background-light border border-[#f0f2f4] font-bold hover:border-primary/30 transition"
                               href="<?php echo e(route('recruiter.offers.applications', $offer)); ?>">
                                Candidatures
                            </a>
                            <a class="px-4 py-2 rounded-xl bg-background-light border border-[#f0f2f4] font-bold hover:border-primary/30 transition"
                               href="<?php echo e(route('recruiter.offers.edit', $offer)); ?>">
                                Modifier
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-6 text-sm text-muted">Aucune offre créée pour le moment.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/thejackal/Documents/Sprint6/Espace-d-Emploi/resources/views/dashboard/recruiter.blade.php ENDPATH**/ ?>